package com;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

/**
 * Servlet implementation class ChangePassword
 */
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(Password.class);
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String new_pass = request.getParameter("new_password");
		String current_pass = request.getParameter("current_password");
		logger.info("current_pass  "+current_pass);
		String accountNumber = (String)session.getAttribute("account_number");
		logger.info("accountNumber     "+accountNumber);
		String current_password = "";
		String new_password = "";
		String fdate = (String)session.getAttribute("new_from_date");
		String tdate = (String)session.getAttribute("new_to_date");
		logger.info("f date     "+fdate+"  t date   "+tdate);
		try {
			 MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] hashInBytes = md.digest(current_pass.getBytes(StandardCharsets.UTF_8));
		        byte[] new_hashInBytes = md.digest(new_pass.getBytes(StandardCharsets.UTF_8));

		        StringBuilder sb = new StringBuilder();
		        StringBuilder new_sb = new StringBuilder();
		        for (byte b : hashInBytes) {
		            sb.append(String.format("%02x", b));
		        }
		        
		        for (byte b : new_hashInBytes) {
		        	new_sb.append(String.format("%02x", b));
		        }
		        
		        current_password = sb.toString();
		        new_password = new_sb.toString();
		        logger.info("encryprion password   "+current_password);
		}catch(Exception e) {
			logger.error(e);
//			e.getMessage();
		}
		
		JSONObject obj = new JSONObject();
		obj.put("accountNumber", accountNumber);
		obj.put("oldPassword", current_password);
		obj.put("newPassword", new_password);
		
		String data = obj.toString();
		logger.info("data  "+data);
//		System.out.println("jsonobject   "+obj);
		
		   Properties prop = new Properties();
		    ServletContext context = getServletContext();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
//		        host = prop.getProperty("uatint_host");
		        host ="10.251.111.22";
		        
//		        System.out.println("host in password   "+host);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }		
		    
		    String chanepassword_URL = prop.getProperty("change_password");
		    logger.info("register_URL    :    "+chanepassword_URL);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(chanepassword_URL,data,rs,host);
		    logger.info("response   "+api_resp);
		    if(api_resp.contains("Success")){
		    	 session.setAttribute("chane_password_status", "success");
			   	 response.sendRedirect("statements.jsp?fdate="+fdate+"&tdate="+tdate);
			   	 
		    }else{
		    	 session.setAttribute("chane_password_status", "failed");
			   	 response.sendRedirect("statements.jsp?fdate="+fdate+"&tdate="+tdate);
		    }
		    	
	
	}

}
