package com;
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.model.Resources;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

 public class CertConfig
{
		final static Logger logger = Logger.getLogger(CertConfig.class);
public static void certificateConfig(Resources rs,final String host)	 {
		 
		String keyStoreLocation = rs.getKeyStoreLocation();
		String keyStorePass = rs.getKeyStorePass();
		String trustStoreLocation = rs.getTrustStoreLocation();
		String trustStorePass = rs.getTrustStorePass();
	
		 logger.info("keyStoreLocation  :	"+keyStoreLocation);
		 logger.info("keyStorePass  :	"+keyStorePass);
		 logger.info("trustStoreLocation   :	"+trustStoreLocation);
		 logger.info("trustStorePass   :	"+trustStorePass);
		 
			System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
			System.setProperty("https.protocols", "TLSv1.2");
			
			//trust store
			System.setProperty("javax.net.ssl.trustStore",trustStoreLocation);
			System.setProperty("javax.net.ssl.trustStorePassword", trustStorePass);
			
			//key store
			System.setProperty("javax.net.ssl.keyStore",keyStoreLocation);
	        System.setProperty("javax.net.ssl.keyStorePassword", keyStorePass);
			
	        
	        //disable trust store validation if we need
//	        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
//                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
//                    return null;
//                }
//                public void checkClientTrusted(X509Certificate[] certs, String authType) {
//                }
//                public void checkServerTrusted(X509Certificate[] certs, String authType) {
//                }
//            }
//        };
// 
//        // FOR Disabling the Truststore validation the all-trusting trust manager
//        SSLContext sc = null;
//		try {
//			sc = SSLContext.getInstance("SSL");
//		} catch (NoSuchAlgorithmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        try {
//			sc.init(null, trustAllCerts, new java.security.SecureRandom());
//		} catch (KeyManagementException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        
			javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
					new javax.net.ssl.HostnameVerifier() {
//						int i = api_URL.indexOf("/");
//						int k = api_URL.lastIndexOf(":");
//						String ip_address = api_URL.substring(i+2, k);
						public boolean verify(String hostname,
								javax.net.ssl.SSLSession sslSession) {
							if (hostname.equals(host)) {
								return true;
							}
							return false;
						}
					});
		}
	 //main method
   public static void main (String [] argv)
   {
//	   setupHandler();
//		connectToURL(url);
     
   }
  public static void setupHandler(Resources rs,String host)
   {
	  certificateConfig(rs,host);
     java.util.Properties p = System.getProperties();
     String s = p.getProperty("java.protocol.handler.pkgs");
     if (s == null)
       s = "weblogic.net";
     else if (s.indexOf("weblogic.net") == -1)
       s += "|weblogic.net";
     p.put("java.protocol.handler.pkgs", s);
     System.setProperties(p);
   }
    
  public static void connectToURL(String theURLSpec)
   {
     try
     {
       URL theURL = new URL(theURLSpec);
       URLConnection urlConnection = theURL.openConnection();
       HttpURLConnection connection = null;
       if (!(urlConnection instanceof HttpURLConnection))
       {
    	   logger.error("The URL is not using HTTP/HTTPS: " +
                              theURLSpec);
         return;
       }
       connection = (HttpURLConnection) urlConnection;
//       System.out.println("connection      "+connection); 
       connection.connect();
//       System.out.println("done      "); 
     }
     catch (IOException ioe)
     {
    	 logger.info("Failure processing URL: ",  ioe);
       ioe.printStackTrace();
     }
   }
}