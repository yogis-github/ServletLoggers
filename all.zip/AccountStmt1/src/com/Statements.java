package com;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

/**
 * Servlet implementation class Transactions
 */
public class Statements extends HttpServlet {
	final static Logger logger = Logger.getLogger(Statements.class);

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		   HttpSession session = request.getSession();
		   Properties prop = new Properties();
		    ServletContext context = getServletContext();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uat_host");

		       
		    } catch (IOException e) {
		    	logger.error(e.getMessage());
		    }		

		String fromdate = request.getParameter("fromdate");
		String todate = request.getParameter("todate");
		
		String accountNumber = (String)session.getAttribute("account_number");
		String MobileNumber = (String)session.getAttribute("MobileNumber");
		String MerchantId = (String)session.getAttribute("MerchantId");	
		
		String pagesize="10";
		logger.info("accountNumber  "+accountNumber);
		logger.info("MobileNumber  "+MobileNumber);
		logger.info("MerchantId  "+MerchantId);
		logger.info("fromdate  "+fromdate);
		logger.info("todate  "+todate);
		logger.info("pagesize  "+pagesize);

		if(accountNumber!=null && MobileNumber!=null && MerchantId!=null) {
		String new_fromdate="";
		String new_todate="";
		
		try {
			if(fromdate != null && fromdate != "" && todate != null && todate != "") {
		    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		    new_fromdate = sdf2.format(sdf.parse(fromdate));
		    new_todate = sdf2.format(sdf.parse(todate));
			}
			else {			
				try {
					
					   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");  
					   LocalDateTime now = LocalDateTime.now();  
					   fromdate = dtf.format(now);  
					   todate = fromdate;
					   System.out.println("from dat   "+fromdate+"  to date   "+todate);
				    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
				    new_fromdate = sdf2.format(sdf.parse(fromdate));
				    new_todate = sdf2.format(sdf.parse(todate));
				    
					   System.out.println("new_fromdate   "+new_fromdate+"  new_todate   "+new_todate);
		
				} catch (ParseException e) {
				    e.printStackTrace();
				}
			}
		} catch (ParseException e) {
			logger.error(e.getMessage());
//		    e.printStackTrace();
		}
		  		
		String modify_mobileNumber = "";
		String updated_mobile =MobileNumber.trim();
		if(updated_mobile.contains("+91()")) {
			modify_mobileNumber = updated_mobile.replace("+91()", "91");
		}
		else if (updated_mobile.contains("+91")) {
			modify_mobileNumber = updated_mobile.replace("+91", "91");
		}
		else if (updated_mobile.contains("9191")) {
			modify_mobileNumber = updated_mobile.replace("9191", "91");
		}
			else if (updated_mobile.contains("91()")) {
			modify_mobileNumber = updated_mobile.replace("91()", "91");
		}
		else {
			modify_mobileNumber = updated_mobile;
		}
		logger.info("updated mobile number  "+modify_mobileNumber);
		JSONObject obj = new JSONObject();
		obj.put("toDate", new_todate);
		obj.put("fromDate", new_fromdate);
		obj.put("mobileNumber", modify_mobileNumber);
		obj.put("merchantId", MerchantId);
		obj.put("pageSize", pagesize);
	
		
		String data = obj.toString();
		logger.info("data  "+data);
	
		    String postData_url = prop.getProperty("postData_url");
			logger.info("postData_url  "+postData_url);
		    UrlCalls url = new UrlCalls();
			
		    String api_resp =url.APICall(postData_url,data,rs,host);
		    logger.info("response  "+api_resp);
		    if(api_resp.contains("transactionType") || api_resp.equals("[]") || api_resp.contains("Lortza")){
		    	session.setAttribute("table_data", api_resp);
			   	response.sendRedirect("statements.jsp");
		    }
		    else{
		    	if(api_resp.contains("Internal Server Error")) {
		    		session.setAttribute("errorResponse", "Internal Server Error");
				   	response.sendRedirect("statements.jsp");
		    	}else {
		    		session.setAttribute("status", "failed");
				   	response.sendRedirect("login.jsp");
		    	}
		    }	

	}
//		------------------------------------------
//	else {
//		System.out.println("in else condtion   "+accountNumber);
//		String final_data = (String)session.getAttribute("final_data");
//
//		if(final_data!=null) {
//		JSONObject jsonObject = new JSONObject(final_data);
//
//		System.out.println("in SIDE FINAL DATA condtion   "+accountNumber);
//
//			  accountNumber = (String)jsonObject.get("AccountNumber");
//		      MerchantId = (String)jsonObject.get("MerchantId");
//		      MobileNumber = (String)jsonObject.get("MobileNumber");
//		      System.out.println("inGET ACCOUNT NUMBER FROM JSON OJECT "+accountNumber);
//		}
//		
//		String new_fromdate="";
//		String new_todate="";
//		
//		try {
//			
//			   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");  
//			   LocalDateTime now = LocalDateTime.now();  
//			   fromdate = dtf.format(now);  
//			   todate = fromdate;
//			   System.out.println("from dat   "+fromdate+"  to date   "+todate);
//		    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//		    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
//		    new_fromdate = sdf2.format(sdf.parse(fromdate));
//		    new_todate = sdf2.format(sdf.parse(todate));
//		    
//			   System.out.println("new_fromdate   "+new_fromdate+"  new_todate   "+new_todate);
//
//		} catch (ParseException e) {
//		    e.printStackTrace();
//		}
//		  
//		  
//		
//		String modify_mobileNumber = "";
//		String updated_mobile =MobileNumber.trim();
//		if(updated_mobile.contains("+91()")) {
//			modify_mobileNumber = updated_mobile.replace("+91()", "91");
//		}
//		else if (updated_mobile.contains("+91")) {
//			modify_mobileNumber = updated_mobile.replace("+91", "91");
//		}
//		else if (updated_mobile.contains("9191")) {
//			modify_mobileNumber = updated_mobile.replace("9191", "91");
//		}
//			else if (updated_mobile.contains("91()")) {
//			modify_mobileNumber = updated_mobile.replace("91()", "91");
//		}
//		else {
//			modify_mobileNumber = updated_mobile;
//		}
//		
//		JSONObject obj = new JSONObject();
//		obj.put("toDate", new_todate);
//		obj.put("fromDate", new_fromdate);
//		obj.put("mobileNumber", modify_mobileNumber);
//		obj.put("merchantId", MerchantId);
//		obj.put("pageSize", pagesize);
//	
//		
//		String data = obj.toString();
//		System.out.println("jsonobject   "+obj);
//		
//				
//		    
//		    String postData_url = prop.getProperty("postData_url");
//		    System.out.println("postData_url  in statements java classs  :    "+postData_url);
//		    UrlCalls url = new UrlCalls();
//			
//		    String api_resp =url.APICall(postData_url,data,rs,host);
//		    System.out.println("response in Login java    "+api_resp);
//		    if(api_resp.contains("transactionType") || api_resp.equals("[]") || api_resp.contains("Lortza")){
////		    	request.setAttribute("table_data", api_resp);
//		    	session.setAttribute("table_data", api_resp);
////			   	 request.getRequestDispatcher("stmt.jsp").forward(request, response);
//		    	response.sendRedirect("statements.jsp");
//		    }
//		    else{
//		    	System.out.println("inside else condtion    ");
////		    	request.setAttribute("status", "failed");
////			   	 request.getRequestDispatcher("login.jsp").forward(request, response);
//		    	session.setAttribute("status", "failed");
//		    	response.sendRedirect("statements.jsp");
//
//		    }	
//
//	
//		
//		
//	}
	
	}
}
