package com;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

public class stmt extends HttpServlet{
	public String getResponse(String path,String fromdate,String todate,String accountNumber,String MobileNumber,String MerchantId,HttpServletRequest request) {
		String api_resp = "";
		HttpSession session = request.getSession();
		Properties prop = new Properties();
		Resources rs = null;
		String host = "";
		try {
	        prop.load(new FileReader(path));
	        AssignProperties asp = new AssignProperties();
	        rs = asp.setResources(prop);
	        host = prop.getProperty("uat_host");

	       
	    } catch (IOException e) {
			e.printStackTrace();	
		}	
		
		
		
		String pagesize="10";		
		if(accountNumber!=null && MobileNumber!=null && MerchantId!=null) {
			String new_fromdate="";
			String new_todate="";
			String mesg = "";
			
		
			String modify_mobileNumber = "";
			String updated_mobile =MobileNumber.trim();
			if(updated_mobile.contains("+91()")) {
			modify_mobileNumber = updated_mobile.replace("+91()", "91");
			}
			else if (updated_mobile.contains("+91")) {
			modify_mobileNumber = updated_mobile.replace("+91", "91");
			}
			else if (updated_mobile.contains("9191")) {
			modify_mobileNumber = updated_mobile.replace("9191", "91");
			}
			else if (updated_mobile.contains("91()")) {
			modify_mobileNumber = updated_mobile.replace("91()", "91");
			}
			else {
			modify_mobileNumber = updated_mobile;
			}
			
			session.setAttribute("new_from_date", new_fromdate);
			session.setAttribute("new_to_date", new_todate);
			try {
				JSONObject obj = new JSONObject();
				obj.put("toDate", new_todate);
				obj.put("fromDate", new_fromdate);
				obj.put("mobileNumber", modify_mobileNumber);
				obj.put("merchantId", MerchantId);
				obj.put("pageSize", pagesize);
				
				String data = obj.toString();
				System.out.println("data object "+data);
				String postData_url = prop.getProperty("postData_url");
				UrlCalls url = new UrlCalls();
				
				api_resp = url.APICall(postData_url,data,rs,host);
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		return api_resp;
	}
}
