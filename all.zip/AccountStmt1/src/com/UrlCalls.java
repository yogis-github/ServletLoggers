package com;

import org.apache.log4j.Logger;

import com.model.Resources;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class UrlCalls {
	final static Logger logger = Logger.getLogger(UrlCalls.class);

	//for Account Number validation
	  public String APICall(String URL,String data,Resources rs,String host)
	  {
		  CertConfig ct = new CertConfig();  
		  CertConfig.setupHandler(rs,host);
		  CertConfig.connectToURL(URL);
		  
		  String output ="";
		  try {
			    System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		 		Client client = Client.create();				    
		 		WebResource webResource = client.resource(URL);
		 		logger.info("data  "+data);
		 		ClientResponse res = webResource.accept("application/json")
		 	               .type("application/json").post(ClientResponse.class, data);
//		 		ClientResponse res = webResource.header("Content-Type","application/json").post(ClientResponse.class,data);
		 		output = res.getEntity(String.class);	
		 		logger.info("output  "+output);
		  } catch (Exception e) {
			  logger.error(e.getMessage());
//		 		e.printStackTrace();
		 	  }   
		  return output;
	  }
	  
	  
	  //for OTP Validation
	 public String signUpOTP(String url,String header_key, String header_val,Resources rs,String host)
	  {
		 CertConfig ct = new CertConfig();  
		  CertConfig.setupHandler(rs,host);
		  CertConfig.connectToURL(url);
		 String output = "";
		  try {
			    System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		 		Client client = Client.create();						
		 		WebResource webResource = client.resource(url);		 		
		 		ClientResponse res = webResource.header(header_key,header_val).get(ClientResponse.class);
		 		output = res.getEntity(String.class);		 	
		 	  } catch (Exception e) {
		 		  logger.error(e.getMessage());
//		 		e.printStackTrace();
		 	  }		    
		  return output;
	  }
	  
	  public String postData(String url,String data,Resources rs,String host)
	  {
		  CertConfig ct = new CertConfig();  
		  CertConfig.setupHandler(rs,host);
		  CertConfig.connectToURL(url);
		  String output = "";
		  try {
			    System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		 		Client client = Client.create();				    
		 		WebResource webResource = client.resource(url);
		 		logger.info("data  "+data);
		 		ClientResponse res = webResource.header("Content-Type","application/json").post(ClientResponse.class,data);
		 		output = res.getEntity(String.class);		
		  } catch (Exception e) {
			  logger.error(e.getMessage());
		 	  }   
		  return output;
	  }
	  
public static void main(String[] args) {
	
}
}
