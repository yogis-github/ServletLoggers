package com;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.model.AssignProperties;
import com.model.Resources;

/**
 * Servlet implementation class Signup
 */
public class Signup extends HttpServlet {
	final static Logger logger = Logger.getLogger(Signup.class);

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("login.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		String accountNumber = request.getParameter("account_number");
		logger.info("account number  "+accountNumber);		
		   Properties prop = new Properties();
		    ServletContext context = getServletContext();
		    Resources rs = null;
		    String host = "";
		    try {
		        prop.load(new FileReader(context.getRealPath("/WEB-INF/certificate.properties")));
		        AssignProperties asp = new AssignProperties();
		        rs = asp.setResources(prop);
		        host = prop.getProperty("uatint_host");
		     
		    } catch (IOException e) {
		    	logger.error(e.getMessage());
		    }		
		    
		    String signup_URL = prop.getProperty("signup_URL");
		    logger.info("Signup_URL    :    "+signup_URL);
		    UrlCalls url = new UrlCalls();
			String key = "accountNumber";
			String value = accountNumber;
		    String api_resp =url.signUpOTP(signup_URL,key,value,rs,host);
		    logger.info("response   "+api_resp);
		    if(api_resp.contains("Success")){
		    	session.setAttribute("account_number", accountNumber);
			   	response.sendRedirect("otp1.jsp");
		    }else{
		    	session.setAttribute("signup_status", "failed");
			   	response.sendRedirect("sign.jsp");
		    }		    
	}
}
