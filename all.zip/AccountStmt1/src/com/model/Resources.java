package com.model;

public class Resources {
private String trustStoreLocation;
private String trustStorePass;
private String keyStoreLocation;
private String keyStorePass;
private String uat_host;
private String uatint_host;
private String testing_host;


public String getTesting_host() {
	return testing_host;
}
public void setTesting_host(String testing_host) {
	this.testing_host = testing_host;
}
public String getUat_host() {
	return uat_host;
}
public void setUat_host(String uat_host) {
	this.uat_host = uat_host;
}
public String getUatint_host() {
	return uatint_host;
}
public void setUatint_host(String uatint_host) {
	this.uatint_host = uatint_host;
}
public String getTrustStoreLocation() {
	return trustStoreLocation;
}
public void setTrustStoreLocation(String trustStoreLocation) {
	this.trustStoreLocation = trustStoreLocation;
}
public String getTrustStorePass() {
	return trustStorePass;
}
public void setTrustStorePass(String trustStorePass) {
	this.trustStorePass = trustStorePass;
}
public String getKeyStoreLocation() {
	return keyStoreLocation;
}
public void setKeyStoreLocation(String keyStoreLocation) {
	this.keyStoreLocation = keyStoreLocation;
}
public String getKeyStorePass() {
	return keyStorePass;
}
public void setKeyStorePass(String keyStorePass) {
	this.keyStorePass = keyStorePass;
}

}
