package com.model;

import java.util.Properties;

public class AssignProperties {
	
	public static Resources setResources(Properties prop) {
		Resources rs = new Resources();
		
		  String trustStoreLocation = prop.getProperty("trustStoreLocation");
	        String trustStorePass = prop.getProperty("trustStorePass");        
	        String keyStoreLocation = prop.getProperty("keyStoreLocation");
	        String keyStorePass = prop.getProperty("keyStorePass");
	        String uat_host = prop.getProperty("uat_host");
	        String uatint_host = prop.getProperty("uatint_host");
	        String testing_host = prop.getProperty("test_host");
	        
//	        System.out.println("testing host    "+testing_host);
	        rs.setKeyStoreLocation(keyStoreLocation);
	        rs.setKeyStorePass(keyStorePass);
	        rs.setTrustStoreLocation(trustStoreLocation);
	        rs.setTrustStorePass(trustStorePass);
	       rs.setUatint_host(uatint_host);
	       rs.setUat_host(uat_host);
	       rs.setTesting_host(testing_host);
	       
	       
	        
	        return rs;
	}
public static void main(String[] args) {
	
	
}
}
