  function Export() {
	  document.getElementById('loadingDiv').style.display = "block";
//	  alert("in side table  ");
            html2canvas(document.getElementById('example'), {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 480
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Statements.pdf");
                    document.getElementById('loadingDiv').style.display = "none";
                }
            });
           
        }
  
  
  function printData()
  {
     var divToPrint=document.getElementById("example");
     newWin= window.open("");
     newWin.document.write(divToPrint.outerHTML);
     newWin.print();
     newWin.close();
  }