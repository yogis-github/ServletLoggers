// ========== gblobal variables =============
var windowHeight = $(window).height();
var windowWidth = $(window).width();
// ========== window load ============
$(window).load(function(){
    // preloader
    $('#preloader').delay(1500).fadeOut('20000',function(){
      $(this).remove();
    });
});
// ========== document ready ============
$(document).ready(function(){
    //########### page animation ############
    //Cache reference to window and animation items
    var jQueryanimation_elements = jQuery('.animated');
    var jQuerywindow = jQuery(window);

    function check_if_in_view() {
      var window_height = jQuerywindow.height();
      var window_top_position = jQuerywindow.scrollTop();
      var window_bottom_position = (window_top_position + window_height);
     
      jQuery.each(jQueryanimation_elements, function() {
        var jQueryelement = $(this);
        var element_height = jQueryelement.outerHeight();
        var element_top_position = jQueryelement.offset().top;
        var element_bottom_position = (element_top_position + element_height);
     
        //check to see if this current container is within viewport
        if ((element_bottom_position >= window_top_position) &&
            (element_top_position <= window_bottom_position)) {
          jQueryelement.addClass('fadeInUp delay');
        } else {
          jQueryelement.removeClass('fadeInUp delay');
        }
      });
    }
    jQuerywindow.on('scroll resize', check_if_in_view);
    jQuerywindow.trigger('scroll');
	/* ===== search in put nav ===== */
	$(".all-nav-wrap .desktop-contacts-wrap .search-all a").on("click", function(){
		$(this).parent().children("input").toggleClass("search-active-toggle");
	});
    /* ===== Big Menu ===== */
    // activing level 1 menu
    $(".big-menu-wrap .first-level-row .big-first-row-ul .big-first-row-li a").mouseenter(function(){
        $(".big-menu-wrap .first-level-row .big-first-row-ul .big-first-row-li a").removeClass("underliner");
        $(this).addClass("underliner");
        // second line hightlighter
        var levelOneIndex = $(this).parent().index() + 2;
        $(".big-menu-wrap .second-level-row").hide();
        $(".big-menu-wrap .second-level-row:nth-child("+levelOneIndex+")").show();
    });
    // activing level 1 menu switching
    // hovering direction to big menu
    $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li a").mouseenter(function(){
        var menuValNumber = $(this).attr("data-menu-value");
        $(".big-menu-wrap").fadeOut(100);
        $(".big-menu-wrap:nth-child("+ menuValNumber +")").fadeIn(250);
    });
    $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li a, .big-menu-wrap").mouseleave(function(){
        var menuValNumber = $(this).attr("data-menu-value");
        $(".big-menu-wrap").hide();
        $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li a .downtip").hide(100);
        $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li a").removeClass("main-nav-active");
    });
    // big active area mouse hover;
    $(".big-menu-wrap").mouseenter(function(){
        var wrapIndex = $(this).index() + 1;
        $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li a .downtip").hide(100);
        $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li:nth-child("+wrapIndex+") a .downtip").show(200);
        $(".all-nav-wrap .desk-nav-wrap .desk-nav .desk-main-navs .desk-mian-nav-ul .desk-main-nav-li:nth-child("+wrapIndex+") a").addClass("main-nav-active");
    });
	// banner owl carousel
	var banner_owl = $(".banner-slider");
	var banner_owl_settings = {
		items:1,
        loop:true,
        autoplay:true,
        autoplayTimeout:5000,
        autoplaySpeed:900,
        dots:true,
        nav:false,
        responsive:{
            0:{nav:false},
            768:{nav:false}
        }
	}
    // owl initialsised
    banner_owl.owlCarousel(banner_owl_settings);
    // right panel button action
    $(".all-banner-wrap .right-panel-items .right-panel-button").mouseenter(function(){
        $(".all-banner-wrap .right-panel-detailer").css("z-index","1");
        var buttonIndex = $(this).attr("data-right-panel-button");
        $(".all-banner-wrap .right-panel-detailer .panel-detail-item").hide();
        $('.all-banner-wrap .right-panel-detailer .panel-detail-item:nth-child('+ buttonIndex +')').show('fade',{direction:'right'},250);
        // console.log(length);
    }).mouseleave(function(){
        $(".all-banner-wrap .right-panel-detailer").css("z-index","0");
        $(".all-banner-wrap .right-panel-detailer .panel-detail-item").hide();  
    });
    // inside holder
    $(".all-banner-wrap .right-panel-detailer .panel-detail-item").mouseenter(function(){
        $(".all-banner-wrap .right-panel-detailer").css("z-index","1");
        $(this).show();

    }).mouseleave(function(){
        $(this).hide();
    });
    // product list owl carousel
    var productList = $(".product-list-owl");
    var productList_settings = {
        items:4,
        loop:false,
        margin:1,
        dots:false,
        nav:true,
        navText:["<i class='ion-ios-arrow-left'></i>","<i class='ion-ios-arrow-right'></i>"],
        responsive:{
            0:{items:1},
            768:{items:2},
            1100:{items:3},
            1400:{items:4}
        }
    }
    // owl initialsised
    productList.owlCarousel(productList_settings);
    // interested owl owl icons slider
    var interestedOwl = $(".int-point-owl");
    var interestedOwl_settings = {
        items:5,
        loop:false,
        margin:10,
        mouseDrag:false,
        dots:false,
        nav:false,
        navText:["<i class='ion-ios-arrow-left'></i>","<i class='ion-ios-arrow-right'></i>"],
        responsive:{
            0:{nav:false,items:2},
            420:{items:3},
            600:{items:5},
            768:{nav:false,items:5}
        }
    }
    // owl initialsised
    interestedOwl.owlCarousel(interestedOwl_settings);
    // intrest explain detail shower
    $(".intrested-wrap .int-point-owl .int-point-bt").click(function(){
        $(".intrested-wrap .int-point-owl .int-point-bt").removeClass("activer");
        $(this).addClass("activer");
        var expId = $(this).attr("data-explain-button");

        // alert(expId);
        $(".int-explainer-wrap .int-explain-item").fadeOut(200);
        $(".int-explainer-wrap .int-explain-item:nth-child("+expId+")").fadeIn(200);
    });
    // news feed owl carousel home
    var homeNewsFeed = $(".news-feed-owl");
    var homeNewsFeed_settings = {
        items:1,
        loop:false,
        dots:false,
        nav:true,
        navText:["<i class='ion-ios-arrow-left'></i>","<i class='ion-ios-arrow-right'></i>"],
        responsive:{
            0:{nav:true},
            768:{nav:true}
        }
    }
    // owl initialsised
    homeNewsFeed.owlCarousel(homeNewsFeed_settings);
    // i want to slider owl carousel home
    var wantTo = $(".want-to-owl");
    var wantTo_settings = {
        items:5,
        loop:false,
        dots:false,
        margin:10,
        nav:false,
        navText:["<i class='ion-ios-arrow-left'></i>","<i class='ion-ios-arrow-right'></i>"],
        responsive:{
            0:{items:2},
            400:{items:3},
            550:{nav:true,items:4},
            600:{nav:false}
        }
    }
    // owl initialsised
    wantTo.owlCarousel(wantTo_settings);
    // accordian clicker
    $(".how-do-accrodian-wrap .how-do-parent-ul .how-do-parent-li .accordian-button").click(function(){
        $(".how-do-nested-ul").slideUp(150);
        $(this).parent().children(".how-do-nested-ul").slideToggle(150);
    });
    // couting up for facts
    // $('.fact-count').counterUp({
    //     delay: 10,
    //     time: 1000
    // });
    // ((((((( slider for our savings account section common )))))
    var commonOurSavings = $(".our-savings-common-slider");
    var commonOurSavings_settings = {
        items:3,
        loop:false,
        dots:false,
        margin:10,
        nav:false,
        // navText:["<i class='ion-ios-arrow-left'></i>","<i class='ion-ios-arrow-right'></i>"],
        responsive:{
            0:{items:1},
            550:{nav:false,items:2},
            991:{nav:false,items:3}
        }
    }
    // owl initialsised
    commonOurSavings.owlCarousel(commonOurSavings_settings);
});
// mobile menu actions
function mobileMenu (){
    // mobile menu
    $(".mobile-menu-stag a").on("click", function(){
        $(".mobile-nav-wrap").toggleClass("toggle-menu");
        $("main.mobile-wrap, .all-nav-wrap .desk-nav-wrap").toggleClass("all-wrap-toggle");
    });
    // mobile-accordian
    // level one accordian
    $(".mobile-nav-wrap .all-mob-nav-wrap .mob-menu-parent-ul .mob-menu-parent-li span.parent-plus").click(function(){
        if($(this).hasClass('active-accordian')){
          $(this).parent().children(".mob-one-nest-ul").slideUp(50);
          $(".mobile-nav-wrap .all-mob-nav-wrap .mob-menu-parent-ul .mob-menu-parent-li span.parent-plus").removeClass("active-accordian");
        }
        else{
          $(".mobile-nav-wrap .all-mob-nav-wrap .mob-menu-parent-ul .mob-menu-parent-li span.parent-plus").removeClass("active-accordian");
        $(this).addClass("active-accordian");

        $(".mobile-nav-wrap .all-mob-nav-wrap .mob-menu-parent-ul .mob-menu-parent-li .mob-one-nest-ul").slideUp(50);
        $(this).parent().children(".mobile-nav-wrap .all-mob-nav-wrap .mob-menu-parent-ul .mob-menu-parent-li .mob-one-nest-ul").slideDown(50);
        }  
    });
    // level two
    $(".mobile-nav-wrap .all-mob-nav-wrap .mob-one-nest-ul .mob-one-nest-li span.one-plus").click(function(){
        if($(this).hasClass('active-accordian')){
          $(this).parent().children(".mob-two-nest-ul").slideUp(50);
          $(".mobile-nav-wrap .all-mob-nav-wrap .mob-one-nest-ul .mob-one-nest-li span").removeClass("active-accordian");
        }
        else{
          $(".mobile-nav-wrap .all-mob-nav-wrap .mob-one-nest-ul .mob-one-nest-li span").removeClass("active-accordian");
        $(this).addClass("active-accordian");

        $(".mobile-nav-wrap .all-mob-nav-wrap .mob-one-nest-ul .mob-one-nest-li .mob-two-nest-ul").slideUp(50);
        $(this).parent().children(".mobile-nav-wrap .all-mob-nav-wrap .mob-one-nest-ul .mob-one-nest-li .mob-two-nest-ul").slideDown(50);
        }  
    });
    // level three
    $(".mobile-nav-wrap .all-mob-nav-wrap .mob-two-nest-ul .mob-two-nest-li span.two-plus").click(function(){
        if($(this).hasClass('active-accordian')){
          $(this).parent().children(".mob-three-nest-ul").slideUp(50);
          $(".mobile-nav-wrap .all-mob-nav-wrap .mob-two-nest-ul .mob-two-nest-li span").removeClass("active-accordian");
        }
        else{
          $(".mobile-nav-wrap .all-mob-nav-wrap .mob-two-nest-ul .mob-two-nest-li span").removeClass("active-accordian");
        $(this).addClass("active-accordian");

        $(".mobile-nav-wrap .all-mob-nav-wrap .mob-two-nest-ul .mob-two-nest-li .mob-three-nest-ul").slideUp(50);
        $(this).parent().children(".mobile-nav-wrap .all-mob-nav-wrap .mob-two-nest-ul .mob-two-nest-li .mob-three-nest-ul").slideDown(50);
        }  
    });
}
if ($(window).width() <= 991) {
    mobileMenu();
    $(".pre-footer-link-head h2").click(function(){
        $(".pre-footer .pre-footer-links").slideUp();
        $(this).parent().parent().children(".pre-footer-links").slideToggle();
        $(".pre-footer-link-head h2").removeClass("link-active-arrow");
        $(this).addClass("link-active-arrow");
    });
    // overseas accorian
    $(".overseas-country-list-wrap .country-list-ul li.mobile-list-button").click(function(){
        $(".overseas-country-list-wrap .country-list-ul li.mobile-list-button").removeClass("clr-active-tb-bt");
        $(this).addClass("clr-active-tb-bt");
        $(".overseas-country-list-wrap .country-list-ul li").hide();
        $(this).parent().children("li").show();
        $(".overseas-country-list-wrap .country-list-ul li.mobile-list-button").show();
    }); 
}else{
    $(".overScroll").mCustomScrollbar("destroy");
    overScroll();
    // overseas page country contact tab creation
    $(".overseas-country-list-wrap .tab-country-list .country-flag-box").click(function(){
        var buttonAttrVal = $(this).attr("data-country-content");
        // active class add
        $(".overseas-country-list-wrap .tab-country-list .country-flag-box").removeClass("active-country");
        $(this).addClass("active-country");

        $(".overseas-country-list-wrap .country-list-ul").hide();
        $(".overseas-country-list-wrap .country-list-ul:nth-child("+ buttonAttrVal +")").show();
        // alert(buttonAttrVal)
    });
}
function overScroll (){
    // overscrolling inits
    $(".overScroll").mCustomScrollbar({
        axis: "y",
        theme: "minimal-dark",
        autoHideScrollbar: false,
        scrollbarPosition:"outside"
    });
}
// ========== Resize events =============
$(window).resize(function (){
    if ($(window).width() <= 991 ) {
        mobileMenu();
    }else{}
});