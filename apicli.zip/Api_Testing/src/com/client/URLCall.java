package com.client;

import java.net.URL;

import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.cert.X509Certificate;
import java.util.Properties;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;


public class URLCall  implements Runnable{
	
	
	// API URL
	static String api_URL = "";
	// properties file names
	static String keys_data = "resources.properties";// keys Data
	//static String json_data = "json.properties";// Json Data
    int myuid=0;
    int count=4;
    int tcount=4;
    public String tname="";
    final static Logger logger = Logger.getLogger(URLCall.class);
	public URLCall(int count,int tcount) {
		this.count=count;
		this.tcount=tcount;
		Properties prop = new Properties();
		String path = System.getProperty("user.dir");
		FileInputStream input;
		try {
			input = new FileInputStream(keys_data);
			System.out.println(path);
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		api_URL = prop.getProperty("api_URL");
		System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
		System.setProperty("https.protocols", "TLSv1.2");

		// trust store
		System.setProperty("javax.net.ssl.trustStore",
				prop.getProperty("trustStoreLocation"));
		System.setProperty("javax.net.ssl.trustStorePassword",
				prop.getProperty("trustStorePass"));

		// key store
		System.setProperty("javax.net.ssl.keyStore",
				prop.getProperty("keyStoreLocation"));
		System.setProperty("javax.net.ssl.keyStorePassword",
				prop.getProperty("keyStorePass"));

		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs,
					String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs,
					String authType) {
			}
		} };

		javax.net.ssl.HttpsURLConnection
				.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {

					public boolean verify(String hostname,
							javax.net.ssl.SSLSession sslSession) {
						if (hostname.equals(prop.getProperty("hostname"))) {
							return true;
						}
						return false;
					}
				});

	}
	public void process(String mycount) {
		this.setupHandler();
		this.connectToURL(api_URL);

		try {
			Client client = Client.create();
			//String json_data = new String(Files.readAllBytes(Paths.get("json.properties")));

			JSONObject json = new JSONObject();
			 
			json.put("ReferenceId",ThreadLocalRandom.current().nextInt() +  "_"+ new Date().getTime());
			json.put("Time", ""+ new Date().getTime());
			json.put("Thread ID",  mycount);
			WebResource webResource = client.resource(api_URL);

			ClientResponse response = webResource.accept("application/json")
					.type("application/json")
					.post(ClientResponse.class, json.toString());
			String output = response.getEntity(String.class);
			int status = response.getStatus();
			System.out.println("status code    :  " + status);
			System.out.println("Request  :  " + json.toString());
			System.out.println("Response :  " + output.toString());
			
			logger.info("status code    :  " + status);
			logger.info("Request  :  " + json.toString());
			logger.info("Response :  " + output.toString());
			

		} catch (Exception ch) {
			System.out.println("inside client handler exception   ");
			
		} 
	}
	
	
	// main method
	public static void main(String[] argv) throws SecurityException, IOException{
		
		URLCall urlCall=null;
		PropertyConfigurator.configure("log4j.properties");
		logger.info("Starting the Application");
		System.out.println(argv.length);
		if(argv.length==2){
			urlCall = new URLCall(Integer.parseInt(argv[0]), Integer.parseInt(argv[1]));
		}else{
			 urlCall = new URLCall(4, 4);
		}
		
		for(int i=0;i<urlCall.tcount;i++){
		    urlCall.tname=""+ i;
		Thread thread = new Thread(urlCall);		
		thread.start();
		
		
		}
	}

	private void setupHandler() {
		java.util.Properties p = System.getProperties();
		String s = p.getProperty("java.protocol.handler.pkgs");
		if (s == null)
			s = "weblogic.net";
		else if (s.indexOf("weblogic.net") == -1)
			s += "|weblogic.net";
		p.put("java.protocol.handler.pkgs", s);
		System.setProperties(p);
	}

	private void connectToURL(String theURLSpec) {
		try {
			URL theURL = new URL(theURLSpec);
			URLConnection urlConnection = theURL.openConnection();
			HttpURLConnection connection = null;
			if (!(urlConnection instanceof HttpURLConnection)) {
				System.out.println("The URL is not using HTTP/HTTPS: "
						+ theURLSpec);
				return;
			}
			connection = (HttpURLConnection) urlConnection;
			connection.connect();
		} catch (Exception ioe) {
			System.out.println("Failure processing URL: " + theURLSpec);
			ioe.printStackTrace();
			logger.error(ioe.getMessage());
		}
	}

	@Override
	public void run() {
		for(int i=0;i<this.count;i++){
		//	System.out.println(this.tname + " : " +i);	
		this.process(this.tname + " : " +i);
		}
		
	}
}